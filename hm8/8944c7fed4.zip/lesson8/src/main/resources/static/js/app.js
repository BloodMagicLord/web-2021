window.notify = function (message) {
    $.notify(message, {
        position: "right bottom",
        className: "success"
    });
}
