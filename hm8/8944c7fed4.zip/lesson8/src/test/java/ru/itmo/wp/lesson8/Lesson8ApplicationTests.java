package ru.itmo.wp.lesson8.lesson8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
