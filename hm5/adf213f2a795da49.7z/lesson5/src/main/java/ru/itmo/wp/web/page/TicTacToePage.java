package ru.itmo.wp.web.page;

@SuppressWarnings({"unused", "RedundantSuppression"})
public class TicTacToePage {
    // TODO: Implement it.
}
