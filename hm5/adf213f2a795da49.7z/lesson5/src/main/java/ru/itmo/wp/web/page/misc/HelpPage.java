package ru.itmo.wp.web.page.misc;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@SuppressWarnings({"unused", "RedundantSuppression"})
public class HelpPage {
    private void action(HttpServletRequest request, Map<String, Object> view) {
        // No operations.
    }
}
