<template>
    <div>
        <h1>Register</h1>
        <p>Please, implement me!</p>
    </div>
</template>

<script>
export default {
    name: "Register",
}
</script>

<style scoped>

</style>
