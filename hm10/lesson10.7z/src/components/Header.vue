<template>
    <header>
        <a href="#" @click.prevent="changePage('Index')">
            <img src="../assets/img/logo.png" alt="Codeforces" title="Codeforces"/>
        </a>
        <div class="languages">
            <a href="#"><img src="../assets/img/gb.png" alt="In English" title="In English"/></a>
            <a href="#"><img src="../assets/img/ru.png" alt="In Russian" title="In Russian"/></a>
        </div>
        <div class="enter-or-register-box">
            <template v-if="userId">
                {{ users[userId].name }}
                |
                <a href="#" @click.prevent="onLogout">Logout</a>
            </template>
            <template v-else>
                <a href="#" @click.prevent="changePage('Enter')">Enter</a>
                |
                <a href="#">Register</a>
            </template>
        </div>
        <nav>
            <ul>
                <li><a href="#" @click.prevent="changePage('Index')">Home</a></li>
                <li><a href="#">Users</a></li>
                <li v-if="userId"><a href="#" @click.prevent="changePage('WritePost')">Write Post</a></li>
                <li v-if="userId"><a href="#" @click.prevent="changePage('EditPost')">Edit Post</a></li>
            </ul>
        </nav>
    </header>

</template>

<script>
export default {
    name: "Header",
    props: ["userId", "users"],
    methods: {
        changePage: function (page) {
            this.$root.$emit("onChangePage", page);
        },
        onLogout: function () {
            this.$root.$emit("onLogout");
            this.changePage("Index");
        }
    }
}
</script>

<style scoped>

</style>