<template>
    <div>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium
        alias architecto beatae commodi consequuntur distinctio doloremque,
        ea eligendi eveniet, exercitationem fuga id maiores minima modi nemo
        neque nesciunt non nostrum officiis optio quaerat quas recusandae
        reiciendis saepe temporibus. At deserunt quis repudiandae sapiente voluptatum.
        Ea error maiores nulla ratione vitae. Amet aperiam consequuntur corporis cum
        cumque delectus dicta dolor doloribus eaque eligendi eos esse et
        expedita explicabo fugit hic impedit in ipsa labore laudantium modi molestias nisi numquam
        omnis quaerat quam quidem quis quo repellendus repudiandae similique soluta, tempora ut vel
        veritatis vitae voluptatum! Aliquid deserunt doloremque et minus soluta?
    </div>
</template>

<script>
export default {
    name: "Index"
}
</script>

<style scoped>

</style>
